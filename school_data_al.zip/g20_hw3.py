#320201119
#320201118

#Group Members: Ayaaba Fatawu Sumaila and Aaamir Kama Siddiqui

# This program performs data cleaning and statistical analysis on student records and inventory items using two text data.
# It reads data from two text files, cleans the data using the given functions, and computes various statistics for inventory and students data.
# The results are printed in a structured report format using a styling format.
# This program includes functions for loading data, cleaning data, building lists and tuples as elements, and computing statistics.
# Exception handling is implemented in the main function to manage potential errors during file operations.
# The program is designed to be modular, with each function performing a specific task.
# Ourr final report includes cleaned data lists including the given tuple format as elements and statistical summaries.
# The program is intended for educational purposes and demonstrates data processing techniques in Python.

# We got the top student by using assigning the initial score value as the top student
# And then we used a for loop to compair and obtain the best student and assign the highest score to the top student

styling = "="*30 #styling for report analysis sections

# These are the file paths for the data files which are accessible from our local machine.
# Please ensure the file paths are correct and accessible using the filepath from your computer.
students_data = r'C:\Users\hp\Downloads\students_data.txt'
inventory_data= r'C:\Users\hp\Downloads\inventory_data.txt'

#This function loads the raw filepaths with two arguments students_data and inventory_data files.
def load_raw_lines(students_data, inventory_data):
    return students_data,inventory_data
            

#Cleaning the inventory data, it cleans up the inventory data and returns a list of tuples.
def clean_inventory_item():
    #accessing the inventory data file from the load_raw_lines function
    _,inventory_filepath = load_raw_lines(students_data=students_data,inventory_data=inventory_data)
        #Inventory data
    inventory_list = [] #list to hold the inventory data items
    inventory_file = open(inventory_filepath, 'r')
        
    for line in inventory_file:
        #Removing extra spaces, and special characters
        inventory_lines = line.strip()
        inventory_lines = inventory_lines.replace(" ", "")
        inventory_lines = inventory_lines.replace("-", " ")
        inventory_lines = inventory_lines.split("|")

        #Printing None if there is no valid item
        if inventory_lines[-1] == "":
            print("None")

        #Changing the first letter of the first item to capital, and the last item to lowercase and removing "kg" from it.
        else:
            inventory_lines[0] = inventory_lines[0].capitalize()
            inventory_lines[-1] = inventory_lines[-1].lower().replace("kg","")
            inventory_lines[-1] = float(inventory_lines[-1]) #Converting the weight to float type
            inventory_lines = tuple(inventory_lines) #Converting the list to tuple
        inventory_list.append(inventory_lines) #Appending the cleaned inventory items to the inventory list
    inventory_file.close()
    return inventory_list

#Building the inventory list from the cleaned inventory items
def build_inventory():    
    inventory_list = clean_inventory_item()
    return inventory_list

#Cleaning the student records, it cleans up the student data and returns a list of tuples.
def clean_student_record(inventory_filepath):
    students_filepath,_ = load_raw_lines(students_data,inventory_data)
    student_file = open(inventory_filepath, 'r')
        
    student_list = []
    for line in student_file:

       #Removing extra spaces and special characters and splitting the data by ";"
        students_lines = line.strip()
        students_lines = students_lines.split(";")
        if students_lines[-1] == "":
            print("None") #Printing None if there is no valid score
        else:
            students_lines[0] = students_lines[0].capitalize()
            students_lines[1] = students_lines[1].replace("House","")
            students_lines[-1] = students_lines[-1].replace("score=","")
            students_lines[-1] = int(students_lines[-1])
            students_lines = tuple(students_lines)
            #Validating the score to be between 0 and 100 score range
            if (students_lines[-1] >= 0 or students_lines[-1]<=100):
                students_lines=students_lines
            else:
                students_lines = "NN"
        #Students list appending the cleaned student records to the student list
        student_list.append(students_lines)
    return student_list

#Building the student list from the cleaned student records
def build_student_list():
    student_list = clean_student_record(students_data)
    return student_list
    
# This function computes inventory statistical analysis
def compute_inventory_stats():
    
    numberOfItems = len(build_inventory()) #Total number of inventory items

    print(f"Total number of inventory items : {numberOfItems}")
    total_weight = 0
    #Calculating the total weight of inventory items
    for items in build_inventory():

        if items[-1] == "":
            total_weight += 0
        else:
            total_weight += items[-1]
   

    print(f"Total weight: {total_weight:.1f}")
 
    #Getting the heaviest inventory item by comparing the weights of each item using a for loop
    heaviest_weight = build_inventory()[0][-1]
    weight_name = ""
    for heavy in build_inventory():
        #Checking if the last element of the tuple is not empty
        if heavy[-1] != "":
            
            if heaviest_weight < heavy[-1]:
                heaviest_weight = heavy[-1]
                weight_name += heavy[0]

    print(f"Heaviest inventory item {weight_name} weihgts {heaviest_weight}kg\n")

# A function to compute student statistical analysis
def compute_student_stats():
    numberOfstudents = len(build_student_list())
    print(f"Total number of students: {numberOfstudents}")
    #Calculating the total number of students who passed and average score of students
    total_score=0
    passing_count = 0
    # A for loop to count the number of students who passed
    for count in build_student_list():
        #Checking if the last element of the tuple is not empty
        if count[-1] != "":
            if count[-1] >= 60: #Passing score is 60 and above
                passing_count += 1
            else:
                passing_count += 0
    print(f"The number of students who passed = {passing_count}")

    #Calculating the average score of students
    average_score = 0
    for score in build_student_list():
        #Checking if the last element of the tuple is not empty
        if score[-1] != "":
            total_score += score[-1] #Summing up all the scores
    average_score = (total_score / numberOfstudents) #Calculating the average score
    print(f"The average student score = {average_score:.1f}")

    #Top student score and details
    top_student = build_student_list()[0][-1]
    student_name = ""
    student_house = ""
    for student in build_student_list():
        if student[-1] != "":
            #Checking for the highest score among the students, and getting the student name and house
            if top_student < student[-1]:
                top_student = student[-1]
                student_name = student[0]
                student_house = student[1]
    print(f"The highest student name is {student_name}, score = {top_student} and the house is {student_house}")
        

#This function computes the number of students per house
def students_per_house():
    # An empty dictionary to hold the house names and their respective student counts
    house_count = {}
    for student in build_student_list():
        #Checking if the last element of the tuple is not empty
        if student[-1] != "":
            house = student[1]
            #Counting the number of students per house 
            if house not in house_count:
                house_count[house] = 1
            else:
                house_count[house] += 1
    #Printing the number of students per house using a for loop
    for house_name,number in house_count.items():

        print(f"{house_name.sort()} = {number} students")


#Printing the final report with all the analysis sections and data lists
def print_report():
    print(f"<{styling}>")
    print("INVENTORY DATA LIST, WITH TUPLE ELEMENTS\n")
    print(build_inventory())
    print(f"<{styling}>\n")

    print(f"<{styling}>")
    print("STUDENTS DATA LIST, WITH TUPLE ELEMENTS\n")
    print(build_student_list())
    print(f"<{styling}>\n")

    print(f"<{styling}>")
    print("INVENTORY ANALYSIS SUMMARY\n")
    compute_inventory_stats()
    print(styling)

    print(f"<{styling}>")
    print("STUDENT PERFORMANCE SUMMARY\n")
    compute_student_stats()
    print(f"<{styling}>")

    print(f"<{styling}>")
    print("HOUSE DISTRIBUTION SUMMARY\n")
    students_per_house()
    print(f"<{styling}>")

def main():
    #Running the main function with exception handling
    try:
        print_report()
    except Exception as e:
        print(f"Please check, an error occurred. If this error occurs, copy the full file directory(path) from your pc and use it, e.g r'filepath': {e}")

if __name__=='__main__':
    main()